import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Add Elements to My Screen")

WHITE = (255, 255, 255)
BLUE = (0, 128, 255)
BLACK = (0, 0, 0)

font = pygame.font.SysFont("Arial", 36)
rectangle = pygame.Rect(220, 190, 200, 100)
text = font.render("Welcome to My Game!", True, BLACK)
text_rect = text.get_rect(center=(320, 100))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill(WHITE)
    pygame.draw.rect(screen, BLUE, rectangle)
    screen.blit(text, text_rect)
    pygame.display.update()

pygame.quit()
sys.exit()
