import pygame
import random
import sys

pygame.init()
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Space Invader Part 1")

WHITE = (255,255,255)
RED = (255,0,0)
BLACK = (0,0,0)

player = pygame.Rect(300, 400, 50, 50)
enemies = [pygame.Rect(random.randint(0,590), random.randint(0,300), 40, 40) for _ in range(7)]

score = 0
font = pygame.font.SysFont(None, 36)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]: player.x -= 5
    if keys[pygame.K_RIGHT]: player.x += 5

    for enemy in enemies:
        if player.colliderect(enemy):
            score += 1
            enemy.x = random.randint(0,590)
            enemy.y = random.randint(0,300)

    screen.fill(WHITE)
    pygame.draw.rect(screen, RED, player)
    for enemy in enemies:
        pygame.draw.rect(screen, BLACK, enemy)

    score_text = font.render(f"Score: {score}", True, BLACK)
    screen.blit(score_text, (10,10))

    pygame.display.update()

pygame.quit()
sys.exit()
