import pygame
import sys

pygame.init()
pygame.mixer.init()

screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Space Invader Part 2")

# Add your own background image named 'background.jpg' in same folder
# Add your own sound file named 'sound.wav' in same folder

try:
    background = pygame.image.load("background.jpg")
    sound = pygame.mixer.Sound("sound.wav")
    sound.play(-1)
except:
    background = None

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if background:
        screen.blit(background, (0,0))
    else:
        screen.fill((0,0,0))

    pygame.display.update()

pygame.quit()
sys.exit()
